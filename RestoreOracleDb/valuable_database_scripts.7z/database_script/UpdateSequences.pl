#!@PERL_PATH@
#
# File    : UpdateSequences.pl
#
# Purpose : Update Sequence Values
#
# Author  : Steve R. Hanchar
#
# Date    : 15-Feb-2000
#
# Usage   : UpdateSequences -h -v -d -u -f <sequence file> -s <sequence name(s)>
#
###############################################################################
#
# Include needed sub-components
#
require "getopts.pl";
#
use lib "$ENV{MOCADIR}/scripts";
#use MocaReg;
#
################################################################################
#
# Initialize internal parameters
#
#if ($^O =~ /win32/i)
#{			    # NT
#    $par_pthsep = "\\";
#    #
#    $par_dbslib = MocaReg->get ("Server", "dblib");
#    $par_dbscnv = MocaReg->get ("Server", "sql-convert");
#    if (($par_dbslib =~ /MOCAmado/i) && ($par_dbscnv =~ /Y/i))
#    {
#	$par_dbsven = "SQLSERVER";
#    }
#    else
#    {
#	$par_dbsven = "ORACLE";
#    }
#}
#else
#{			    # Unix
#    $par_pthsep = "\/";
#    $par_dbsven = "ORACLE";
#}
################################################################################
#
# This is a hack
#
$db_url = $ENV{MOCA_DBURL};

if ($db_url =~ /sqlserver/i )
{
    $par_dbsven = 'SQLSERVER';
}
elsif ($db_url =~ /oracle/i )
{
    $par_dbsven = 'ORACLE';
}
#
# End hack
#
#################################################################################
#
#$par_seqfil = "${par_pthsep}db${par_pthsep}ddl${par_pthsep}Sequences${par_pthsep}UpdateSequences.dat";
$par_seqfil = "";
#
#$par_seqloc = "TMDIR.req | SALDIR.opt | MCSDIR.opt | SLDIR.opt | LESDIR.opt";
$par_seqfil = "";
#
################################################################################
#
# Initialize internal variables
#
$arg_vbsflg = "";
#
$arg_dbgflg = "";
#
$arg_updflg = "";
#
$arg_seqfil = "";
#
$arg_seqnam = "";
#
###############################################################################
#
# Define print help routine
#
sub print_help()
{
    printf ("\n");
    printf ("Update active sequence values.  Will account for existing database\n");
    printf ("entries when updating values.\n");
    printf ("\n");
    printf ("Usage:  UpdateSequences -h -v -d -u -f <sequence file> -s <sequence name(s)>\n");
    printf ("\n");
    printf ("    -h) Help mode - display this help screen\n");
    printf ("\n");
    printf ("    -v) Verbose mode - display running status messages\n");
    printf ("\n");
    printf ("    -d) Debug mode - display debug messages\n");
    printf ("\n");
    printf ("    -u) Update sequences - actually update sequence values\n");
    printf ("\n");
    printf ("    -f) Sequence dependency file - see below for format description\n");
    printf ("        (default is '$arg_seqfil')\n");
    printf ("\n");
    printf ("    -s) Sequence name list, format is \"seqnam1,seqnam2,...\"\n");
    printf ("        Identifies which sequence(s) to initialize (include double-quotes)\n");
    printf ("        (default is everything)\n");
    printf ("\n");
    printf ("The sequence dependency file is used to map sequences to database table/field\n");
    printf ("combinations.  The defined combinations will be scanned to find the highest\n");
    printf ("sequence number used for each active sequence.  This is used when updating\n");
    printf ("sequence values to prevent future numbering conflicts with existing data.\n");
    printf ("\n");
    printf ("A sequence dependency file is only needed if your project has any custom\n");
    printf ("database fields that use sequences.  Standard sequence dependencies are\n");
    printf ("always loaded via a separate file, so the only thing needed in the file you\n");
    printf ("may specify would be the custom sequence dependencies your project uses.\n");
    printf ("\n");
    printf ("The sequence dependency file uses the following format for each line.\n");
    printf ("\n");
    printf ("<numcod>|<tblnam>.<fldnam>|<tblnam>.<fldnam>|... repeat as needed\n");
    printf ("\n");
    printf ("<numcod> - Number code (sequence name) as defined in sysctl table.\n");
    printf ("\n");
    printf ("<tblnam>.<fldnam> - Table name and field name of a field that uses the\n");
    printf ("           sequence when creating new entries.\n");
    printf ("\n");
    printf ("Lines beginning with \"#\" are treated as comment lines (i.e. ignored)\n");
    printf ("\n");
}
#
###############################################################################
#
# Define run sql command routine
#
sub run_sql_cmd ()
{
    my ($sqlcmd) = "";
    my ($sqlerr) = "";
    my ($sqlflg) = "";
    my ($sqllin) = 0;
    my ($sqlrsp) = "";
    my ($sqlwrk) = "";
    my ($msqlcmd) = "";
    #
    # Get desired sql command to run
    #
    $sqlcmd = shift @_;
    #
    printf ("\nSqlCmd: ($sqlcmd)\n") if ($arg_dbgflg);
    #
    # Determine working file name and delete any old working files
    #
    $sqlwrk = "$ENV{LESDIR}${par_pthsep}log${par_pthsep}UpdateSequences_$$.tmp";
    if (-e $sqlwrk)
    {
	printf ("\nDeleting old working file ($sqlwrk)\n") if ($arg_dbgflg);
	unlink ($sqlwrk) || die "\nFATAL ERROR - Could not delete old working file ($sqlwrk).\nStopped";
    }
    #
    # Run sql command
    #
    $msqlcmd = "msql -S -i -s > $sqlwrk";
    printf ("\nMSqlCmd: ($msqlcmd)\n") if ($arg_dbgflg);
    open   (SQLCMD, "| $msqlcmd") || die "\nFATAL ERROR - Could not start sql utility.\nStopped";
    printf (SQLCMD " $sqlcmd \n");
    printf (SQLCMD "exit\n");
    close  (SQLCMD) || die "\nFATAL ERROR - Could not run msql utility.\nStopped";
    #
    # Open sql command results file
    #
    open (SQLRSP, $sqlwrk) || die "\nFATAL ERROR - Could not access msql utility results.\nStopped";
    #
    # Read sql command results (filter out result header & blank lines)
    #
    $sqlerr = "";
    $sqlflg = "";
    $sqllin = 0;
    $sqlrsp = "";
    #
    while (<SQLRSP>)
    {
	chomp;
	#
	if (/^\s*$/)
	{
	    next;  # Skip blank lines
	}
	#
	$sqllin = $sqllin + 1;
	#
	if ($sqllin = 2)
	{
	    $sqlerr = $_;   # Grab 2nd non-blank line as potential error line
	}
	#
	if ($sqlflg)
	{
	    s/(^.*\S)\s*$/$1 /;  # Trim excess trailing blanks
	    $sqlrsp .= $_;
	}
	#
	if (/^-/)
	{
	    $sqlflg = "1";  # End of results header detected
	}
    }
    #
    # Verify no errors occurred running sql command
    #
    if (!$sqlrsp)
    {
	if ($sqlerr =~ /Success/i)
	{
	    $sqlerr = "";
	}
	#
	if ($sqlerr =~ /-1403/)
	{
	    $sqlerr = "";
	}
	#
	if ($sqlerr =~ /^Command affected no rows$/i)
	{
	    $sqlerr = "";
	}
    }
    #
    if (!$sqlrsp && $sqlerr)
    {
	printf ("\nFATAL ERROR - Error occurred running sql command\n");
	printf ("\nSqlCmd: ($sqlcmd)\n");
	printf ("SqlErr: ($sqlerr)\n");
	die;
    }
    #
    # Trim trailing blanks from sql command results
    #
    $sqlrsp =~ s/(^.*\S)\s*$/$1/;
    #
    # Close & delete sql command results file
    #
    close  (SQLRSP);
    unlink ($sqlwrk);
    #
    printf ("SqlRsp: ($sqlrsp)\n") if ($arg_dbgflg);
    #
    return $sqlrsp;
}
#
###############################################################################
#
# Input argument checking/processing
#
#
# Get command line arguments
#
$status = &Getopts ('hvduf:s:b');
#
# If help mode enabled, then print help screen & exit
#
if ($opt_h || !$status)
{
    &print_help ();
    exit (0);
}
#
# Load arguments into local variables
#
$arg_vbsflg = "1"    if ($opt_d || $opt_v);
$arg_dbgflg = "1"    if ($opt_d);
$arg_updflg = "1"    if ($opt_u);
#
$arg_seqfil = $opt_f if ($opt_f);
$arg_seqnam = $opt_s if ($opt_s);
#
if ($arg_vbsflg)
{
    printf ("\nArgument List\n");
    printf ("VbsFlg ($arg_vbsflg)\n");
    printf ("DbgFlg ($arg_dbgflg)\n");
    printf ("UpdFlg ($arg_updflg)\n");
    printf ("SeqFil ($arg_seqfil)\n");
    printf ("SeqNam ($arg_seqnam)\n");
}
printf ("\n");
#
# If bootstrap mode enabled, then write new sequence dependency file & exit
#
# Programming Note: This is NOT a documented feature, it only works with Oracle
#
if ($opt_b)
{
    &write_seqdep_file ();
    exit (0);
}
#
# Ensure all required arguments are defined
#
#if (!$arg_seqfil)
#{
#    printf ("\nSequence dependency file not defined\n");
#    &print_help;
#    exit (2);
#}
#
###############################################################################
#
# Load sequence dependency information from standard sequence dependency files
#
printf ("Reading sequence dependency information from standard sequence dependency files\n") if ($arg_vbsflg);
#
# Do for each standard sequence dependency file location
#
foreach $seqloc (split '\|', $par_seqloc)
{
    #
    # Parse location information into individual components
    #
    ($envnam, $reqflg) = split '\.', $seqloc;
    #
    $envnam =~ s/^\s*(\S*)\s*$/$1/;
    $reqflg =~ s/^\s*(\S*)\s*$/$1/;
    #
    printf ("Processing location ($envnam), req=($reqflg)\n") if ($arg_dbgflg);
    #
    # Determine standard sequence dependency file name
    #
    $seqfil = $ENV{$envnam}.$par_seqfil;
    #
    # If standard sequence dependency file does not exist & current
    # location was an optional location, then skip location
    #
    if ((!-e $seqfil) && ($reqflg eq "opt"))
    {
	printf ("File ($seqfil) is not present\n") if ($arg_vbsflg);
	next;
    }
    #
    # Open & read standard sequence dependency file
    #
    open (SEQDEP, $seqfil) || die "\nFATAL ERROR - Could not open standard sequence dependency file ($seqfil).\nStopped";
    #
    printf ("Reading from ($seqfil)\n") if ($arg_vbsflg);
    #
    while (<SEQDEP>)
    {
	chomp;
	#
	if (/^#/)
	{
	    next;  # Skip comments
	}
	#
	# Load sequence dependency into working variables
	#
	($seqnam, @seqdep) = split '\|';
	#
	$seqnam =~ s/^\s*(\S*)\s*$/$1/;
	#
	if ($seqnam =~ /^\s*$/)
	{
	    next;  # Skip blank lines
	}
	#
	# If sequence dependency is not in sequence name list, then skip dependency
	#
	if (($arg_seqnam) && !($arg_seqnam =~ /$seqnam/))
	{
	    printf ("Skipping sequence ($seqnam)\n") if ($arg_dbgflg);
	    next;
	}
	#
	printf ("Reading sequence ($seqnam) dependencies\n") if ($arg_vbsflg);
	#
	# Load sequence dependency into sequence dependency array
	#
	$seqary {$seqnam} = [@{$seqary{$seqnam}}, @seqdep];
	#
	printf ("Sequence ($seqnam) dependency list (@{$seqary {$seqnam}})\n") if ($arg_dbgflg);
    }
    #
    close (SEQDEP);
}
#
###############################################################################
#
# Load sequence dependency information from custom sequence dependency file
#
if ($arg_seqfil)
{
    printf ("Reading sequence dependency information from custom sequence dependency file\n") if ($arg_vbsflg);
    #
    open (SEQDEP, $arg_seqfil) || die "\nFATAL ERROR - Could not open custom sequence dependency file ($arg_seqfil).\nStopped";
    #
    while (<SEQDEP>)
    {
	chomp;
	#
	if (/^#/)
	{
	    next;  # Skip comments
	}
	#
	# Load sequence dependency into working variables
	#
	($seqnam, @seqdep) = split '\|';
	#
	$seqnam =~ s/^\s*(\S*)\s*$/$1/;
	#
	if ($seqnam =~ /^\s*$/)
	{
	    next;  # Skip blank lines
	}
	#
	# If sequence dependency is not in sequence name list, then skip dependency
	#
	if (($arg_seqnam) && !($arg_seqnam =~ /$seqnam/))
	{
	    printf ("Skipping sequence ($seqnam)\n") if ($arg_dbgflg);
	    next;
	}
	#
	printf ("Reading sequence ($seqnam) dependencies\n") if ($arg_vbsflg);
	#
	# Load sequence dependency into sequence dependency array
	#
	$seqary {$seqnam} = [@{$seqary{$seqnam}}, @seqdep];
	#
	printf ("Sequence ($seqnam) dependency list (@{$seqary {$seqnam}})\n") if ($arg_dbgflg);
    }
    #
    close (SEQDEP);
}
#
###############################################################################
#
# For each loaded sequence dependency, determine maximum sequence value used &
# (if needed) update active sequence to prevent future numbering conflicts
#
# Do for each loaded sequence dependency
#
foreach $seqnam (sort keys %seqary)
{
    #
    printf ("\nProcessing sequence ($seqnam)\n") if ($arg_vbsflg);
    #
    # Get active sequence information from sysctl table
    #
    $sqlcmd = "[select '_pfx_'||".
	      "nvl(prefix,'')||'|'||to_char(prelen)||'|'||".
	      "nvl(suffix,'')||'|'||to_char(suflen)||'|'||".
	      "to_char(lstseq)||'|'||to_char(seqlen)||'|'||".
              "to_char(seqflg)||'|'||".
              "to_char(btsflg)||'|' data ".
              " from sysctl ".
              "where numcod = '$seqnam'] catch(-1403)";
    $sqlrsp = &run_sql_cmd ($sqlcmd);
    #
    # If active sequence information is not available, then skip sequence
    #
    if (!($sqlrsp =~ /_pfx_/))
    {
	printf ("Sequence ($seqnam) is not active, skipping it\n") if ($arg_vbsflg);
	next;
    }
    #
    # Load current sequence information into local variables
    #
    ($seqpfx,$seqpln,$seqsfx,$seqsln,$seqlst,$seqlen,$seqflg,$btsflg,$junk) = split '\|', $sqlrsp;
    #
    # Strip prefix keyword, trailing spaces, & double-quotes from prefix & suffix
    #
    $seqpfx =~ s/_pfx_(\w*)\s*/$1/;
    $seqpfx =~ tr/\"//d;
    #
    $seqsfx =~ s/\s*(\w*)\s*/$1/;
    $seqsfx =~ tr/\"//d;
    $btsflg =~ s/\s*(\w*)\s*/$1/;
    printf ("btsflg = $btsflg\n") if ($arg_vbsflg);
    #
    # Verify seqpln & seqsln are set correctly
    #
    if ($seqpln != length $seqpfx)
    {
	$temp = length $seqpfx;
	printf ("\nWARNING: Sequence ($seqnam) actual/declared prefix length ($temp/$seqpln) mismatch\n");
	printf ("WARNING: Using actual sequence prefix length of ($temp)\n\n");
	$seqpln = $temp
    }
    #
    if ($seqsln != length $seqsfx)
    {
	$temp = length $seqsfx;
	printf ("\nWARNING: Sequence ($seqnam) actual/declared prefix length ($temp/$seqsln) mismatch\n");
	printf ("WARNING: Using actual sequence prefix length of ($temp)\n\n");
	$seqsln = $temp
    }
    #
    printf ("Sequence ($seqnam) data: SeqPfx ($seqpfx), SeqPln ($seqpln), SeqSfx ($seqsfx) SeqSln ($seqsln)\n") if ($arg_dbgflg);
    printf ("Sequence ($seqnam) data: SeqLst ($seqlst), SeqLen ($seqlen), SeqFlg ($seqflg)\n") if ($arg_dbgflg);
    #
    # Clear maximum sequence value
    #
    $seqmax = "";
    #
    # Do for each sequence dependancy table/field combination
    #
    foreach $seqdep (@{$seqary{$seqnam}})
    {
	#
	# Parse table/field combination into individual components
	#
	($tblnam, $fldnam) = split '\.', $seqdep;
	#
	$tblnam =~ s/^\s*(\S*)\s*$/$1/;
	$fldnam =~ s/^\s*(\S*)\s*$/$1/;
	#
	printf ("\nProcessing table/field ($tblnam.$fldnam) combination\n") if ($arg_dbgflg);
	#
	# Format sql query to get maximum sequence value for current
	# table/field combination
	#
	if ($par_dbsven eq "ORACLE")
	{
	    $sqlcmd = "[select '_seq_'||max ($fldnam) ".
                      "   from $tblnam ".
                      "  where $fldnam like '$seqpfx%$seqsfx' ";
	}
	else
	{
	    $sqlcmd = "[select '_seq_'||to_char (max ($fldnam)) ".
                      "   from $tblnam ".
                      "  where $fldnam like '$seqpfx%$seqsfx' ";
	}
	#
	# If sequence prefix is defined, then add clause to ensure numerical
	# characters are present after defined prefix.
	#
	if ($seqpln > 0)
	{
	    $sqlcmd .= " and substr ($fldnam, $seqpln + 1, 1) in ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0')";
	}
	#
	# If sequence suffix is defined, then add clause to ensure numerical
	# characters are present before defined suffix.
	#
	if ($seqsln > 0)
	{
	    $sqlcmd .= " and substr ($fldnam, length ($fldnam) - $seqsln, 1) in ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0')";
	}
	#
	# Perform sql query to get maximum sequence value for current
	# table/field combination
	#
        $sqlcmd .= "]";
	$sqlrsp = &run_sql_cmd ($sqlcmd);
	#
	# If current table/field combination is not in use, then skip combination
	#
	if (!($sqlrsp =~ /^\s*_seq_\S+\s*$/))
	{
	    printf ("Table/field combination ($tblnam.$fldnam) not in use, skipping it\n") if ($arg_vbsflg);
	    next;
	}
	#
	# Trim '_seq_' internal keyword from maximum sequence value
	#
	$sqlrsp =~ s/^\s*_seq_(\S+)\s*$/$1/;
	#
	printf ("Table/field combination ($tblnam.$fldnam) max sequence value ($sqlrsp)\n") if ($arg_vbsflg);
	#
	# If current table/field combination max sequence value is higher then current
	# maximum sequence value, then update current maximum sequence value.
	#
	if ($sqlrsp gt $seqmax)
	{
	    $seqmax = $sqlrsp;
	    printf ("Updating sequence ($seqnam) maximum value to ($seqmax)\n") if ($arg_dbgflg);
	}
    }
    #
    # If sequence is not in use, then skip it
    #
    if ($seqmax eq "")
    {
	printf ("Sequence ($seqnam) not in use, skipping it\n");
	next;
    }
    #
    printf ("\nSequence ($seqnam) maximum value is ($seqmax) before adjustment\n") if ($arg_dbgflg);
    #
    # Remove option prefix & suffix strings from maximum sequence number value
    # and verify remainder is a single numeric string
    #
    $seqmax =~ s/.{$seqpln}(.*).{$seqsln}/$1/;
    $seqmax =~ s/^0+([0-9A-Z])/$1/;
    $seqmax = base36_to_base10($seqmax) if ($btsflg eq "1");
    #
    if (!($seqmax =~ /^([0-9A-Z]+)$/))
    {
	printf ("WARNING: Sequence ($seqnam) maximum value ($seqmax) is not an alphanum, skipping\n");
	next;
    }
    #
    # Output an informational status message
    #
    printf ("Sequence ($seqnam) maximum value is ($seqmax)");  # No \n is intentional
    #
    # If updates disabled, then skip to next sequence
    #
    if (!$arg_updflg)
    {
	printf (" - Updates disabled\n");
	next;
    }
    #
    # Output an informational status message
    #
    printf (" - Updating database\n");
    #
    # Update sysctl table sequence information
    #
    $sqlcmd = "[update sysctl ".
              "    set lstseq='$seqmax' ".
              "  where numcod='$seqnam']";
    $sqlrsp = &run_sql_cmd ($sqlcmd);
    #
    # If sequence is maintained by database instead of the app, then
    # update database sequence information
    #
    if ($seqflg != "1")
    {
	#
	# Determine sequence next & maximum value
	#

	$seqnxt = $seqmax + 1;
	$seqlen = $seqlen - $seqpln - $seqsln;
	$seqmax = "9999999999999999999999999999999999999999";
	$seqmax =~ s/(\d{$seqlen})\d*/$1/;

	if ($seqnxt > $seqmax)
	{
	    printf ("\nSequence ($seqnam) value at maximum ($seqmax), ".
                    "reseting to one\n") if ($arg_dbgflg);
	    $seqnxt = 1;
	}

        $sqlcmd = "reseed sequence ".
                  " where sequence = '$seqnam' ".
                  "   and seed = $seqnxt ";
        $sqlrsp = &run_sql_cmd ($sqlcmd);
    }
}
#
###############################################################################
#
# Common exit point for command file.  Perform any required clean-up activities
#
printf ("\n");
exit (0);
#
###############################################################################
#   End of normal script file ################## End of normal script file   ##
###############################################################################
#
# Load non-standard sequence dependency information
#
sub load_seqdep_nonstandard ()
{
    printf ("Getting nonstandard sequence dependency information\n");
    #
    $seqary {"pckgrp"} .= " | ord_line.pckgr1 | ord_line.pckgr2 | ord_line.pckgr3 | ord_line.pckgr4";
}
#
###############################################################################
#
# Load sequence dependency information from database
#
sub load_seqdep_from_database ()
{
    #
    printf ("\n") if ($arg_dbgflg);
    printf ("Getting sequence dependency information from database\n");
    #
    # Do for each defined sequence
    #
    $sqlcmd = "[select rtrim (numcod)||' |' ".
              "   from sysctl ".
              "  order by numcod]";
    $sqlrsp = &run_sql_cmd ($sqlcmd);
    #
    (@seqnam) = split '\|', $sqlrsp;
    #
    foreach $seqnam (@seqnam)
    {
	printf ("\n") if ($arg_dbgflg);
	#
	$seqnam =~ s/^\s*(\S*)\s*$/$1/;
	#
	if ($seqnam =~ /^\s*$/)
	{
	    next;  # Skip blank entry
	}
	#
	# If sequence is not in sequence name list, then skip sequence
	#
	if (($arg_seqnam) && !($arg_seqnam =~ /$seqnam/))
	{
	    printf ("Skipping sequence ($seqnam)\n") if ($arg_dbgflg);
	    next;
	}
	#
	printf ("Getting sequence ($seqnam) dependencies\n") if ($arg_vbsflg);
	#
	# Query database for all tables with a field name that matches sequence name
	#
	$sequpr = $seqnam;
	$sequpr =~ tr/a-z/A-Z/;
	$sqlcmd = "[select rtrim (uc.table_name)||' |' ".
		  "   from user_tab_columns uc, user_objects uo ".
		  "  where uc.table_name = uo.object_name ".
                  "    and uo.object_type='TABLE' ".
                  "    and uc.column_name = '$sequpr' ".
		  "  order by uc.table_name]";
	$sqlrsp = &run_sql_cmd ($sqlcmd);
	#
	# Verify query response is not empty
	#
	if ($sqlrsp eq "")
	{
	    printf ("Sequence ($seqnam) not in use, skipping\n") if ($arg_vbsflg);
	    next;
	}
	#
	# Parse query response into individual table.field combinations
	# & load them into a dependency list
	#
	@seqdep = ();
	#
	$sqlrsp =~ tr /A-Z/a-z/;
	(@tblnam) = split '\|', $sqlrsp;
	#
	foreach $tblnam (@tblnam)
	{
	    $tblnam =~ s/^\s*(\S*)\s*$/$1/;
	    #
	    if ($tblnam =~ /^\s*$/)
	    {
		next;  # Skip blank entry
	    }
	    #
	    printf ("Including table ($tblnam)\n") if ($arg_dbgflg);
	    #
	    $seqary {$seqnam} .= " | $tblnam.$seqnam";
	}
	#
	printf ("Sequence ($seqnam) dependency list ($seqary{$seqnam})\n") if ($arg_dbgflg);
    }
}
#
###############################################################################
#
# Write (new) sequence dependency file
#
sub write_seqdep_file ()
{
    #
    # Initialize sequence dependency file name (don't use parameter value)
    #
    $par_seqfil = "UpdateSequences.dat";
    #
    # Verify sequence dependency file does not already exist
    #
    if (-e $par_seqfil)
    {
	die "\nStandard sequence dependency file ($par_seqfil) already exists,\nStopped";
    }
    #
    # Load non-standard sequence dependency information
    #
    &load_seqdep_nonstandard ();
    #
    # Load sequence dependency information from database
    #
    &load_seqdep_from_database ();
    #
    # Begin creating new sequence dependency file
    #
    printf ("\n") if ($arg_dbgflg);
    printf ("Writing new sequence dependency file\n");
    #
    # Open new sequence dependency file
    #
    open (SEQDEP, ">$par_seqfil") || die "Could not create new sequence dependency file ($par_seqfil),\nStopped";
    #
    # Write sequence dependency file header
    #
    $diemsg = "Could not write to new sequence dependency file ($par_seqfil),\nStopped";
    #
    printf (SEQDEP "# TM sequence dependancy definitions\n")                         || die $diemsg;
    printf (SEQDEP "# (refer to UpdateSequences.pl for more information)\n")              || die $diemsg;
    printf (SEQDEP "#\n")                                                                 || die $diemsg;
    printf (SEQDEP "# Format: numcod|table1.field1|table2.field2|... repeat as needed\n") || die $diemsg;
    printf (SEQDEP "#\n")                                                                 || die $diemsg;
    #
    # Write sequence dependency information to file
    #
    foreach $seqnam (sort keys %seqary)
    {
	$msgtxt = $seqary{$seqnam};
	$msgtxt =~ s/^ \| (.*)/$1/;
	printf ("Writing sequence ($seqnam) dependencies ($msgtxt)\n") if ($arg_dbgflg);
	#
	printf (SEQDEP "$seqnam$seqary{$seqnam}\n") || die $diemsg;
    }
    #
    # Close new sequence dependency file
    #
    close (SEQDEP);
}
#
###############################################################################
#
# convert base 36 sequence to base 10
#
sub base36_to_base10 
{
  my $arg = shift @_;
 
  my $n = 0;
  my %m = ();
  my $c;

  for $c ( split '', '0123456789abcdefghijklmnopqrstuvwxyz' ) 
  {
    $m{ $c } = $n++;
  }
 
  my $argo ="";
  my $len, $ctr; $n;

  $arg = lc($arg);
  $len = length($arg);
  
  #trim leading zeros
  for ($ctr=0; $ctr<$len+1; $ctr ++)
  {
    if (substr($arg, $ctr,1) eq "0" and $argo eq "") {next;}
    $argo .= substr($arg,$ctr,1);
  }

  print "arg: $argo\n";

  $len = length($argo);
  $n = $len-1;
  $ans=0;
  $a = 36**1;
  print "a: $a; m(1): $m(1)\n";
  for ($ctr=0; $ctr<$len; $ctr ++)
  {
    if ($n != 0)
    { 
      $ans = $ans + (36**$n) * $m{ substr( $argo, $ctr, 1 ) };
    }
    else
    { 
      $ans  = $ans + $m{ substr( $argo, $ctr, 1 ) };
    }
    $n= $n-1;
  }
  return ($ans);
}
#
