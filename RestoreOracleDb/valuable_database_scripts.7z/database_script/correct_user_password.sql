alter user &1 identified by &2
/

exit
