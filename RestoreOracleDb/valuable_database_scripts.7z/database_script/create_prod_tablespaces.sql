REM Create tablespaces for shared application library tables and indexes

connect sys/RedPrairie1 as sysdba

create tablespace gen_d_01
   datafile
      'D:\oracle\oradata\orcl\orcl_gend01_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/


create tablespace gen_d_02
   datafile
      'D:\oracle\oradata\orcl\orcl_gend02_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace gen_x_01
   datafile
      'D:\oracle\oradata\orcl\orcl_genx01_01.dbf' size 10m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace gen_x_02
   datafile
      'D:\oracle\oradata\orcl\orcl_genx02_01.dbf' size 10m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_DATA
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_DATA_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_HIST
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_HIST_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_LOCATIONS
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_LOCATIONS2_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_ORDERS
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_ORDERS_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_TEMP
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_TEMP_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_HIST_INDEX
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_HIST_INDEX_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_INDEX
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_INDEX_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_LOCATION_INDEX
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_LOCATION_INDEX_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace TRACS3_ORDER_INDEX
   datafile
      'D:\oracle\oradata\orcl\orcl_TRACS3_ORDER_INDEX_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace PRCL_D_01
   datafile
      'D:\oracle\oradata\orcl\orcl_PRCL_D_01_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace PRCL_X_01
   datafile
      'D:\oracle\oradata\orcl\orcl_PRCL_X_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace DDS_D_01
   datafile
      'D:\oracle\oradata\orcl\orcl_DDS_D_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace DDS_D_02
   datafile
      'D:\oracle\oradata\orcl\orcl_DDS_D_02.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace DDS_X_01
   datafile
      'D:\oracle\oradata\orcl\orcl_DDS_X_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace DDS_X_02
   datafile
      'D:\oracle\oradata\orcl\orcl_DDS_X_02.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_D_01
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_D_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_D_02
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_D_02.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_D_03
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_D_03.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_X_01
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_X_01.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_X_02
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_X_02.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace FP_X_03
   datafile
      'D:\oracle\oradata\orcl\orcl_FP_X_03.dbf' size 20m
      autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

REM --
REM -----------------------------------------------------------------------------
REM --  Script to create Seamles tablespaces 
REM -----------------------------------------------------------------------------

REM * Create the tablespaces for Seamles 
REM *

CREATE TABLESPACE SL_DATA_OTHER DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_other_01.dbf' size 15m
   autoextend on next 15M maxsize 2000M
      extent management local uniform size  1M 
      segment space management auto
/

CREATE TABLESPACE SL_DATA_OTHER_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_other_ind_01.dbf' size 5m
   autoextend on next 5M maxsize 5000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DATA_EO DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_eo_01.dbf' size 150m
   autoextend on next 150M maxsize 2000M
      extent management local uniform size  20M 
      segment space management auto
/

  
CREATE TABLESPACE SL_DATA_EO_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_eo_ind_01.dbf' size 70m
   autoextend on next 70M maxsize 2000M
      extent management local uniform size  10M 
      segment space management auto
/

CREATE TABLESPACE SL_DATA_EVT DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_evt_01.dbf' size 200m
   autoextend on next 200M maxsize 2000M
      extent management local uniform size  20M 
      segment space management auto
/

  
CREATE TABLESPACE SL_DATA_EVT_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_evt_ind_01.dbf' size 150m
   autoextend on next 150M maxsize 2000M
      extent management local uniform size  10M 
      segment space management auto
/

  
CREATE TABLESPACE SL_DATA_IFD DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_ifd_01.dbf' size 300m
   autoextend on next 100M maxsize 5000M
      extent management local uniform size  60M
      segment space management auto
/

  
CREATE TABLESPACE SL_DATA_IFD_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_data_ifd_ind_01.dbf' size 100m
   autoextend on next 100M maxsize 2000M
      extent management local uniform size  10M 
      segment space management auto
/


CREATE TABLESPACE SL_DEF_EO DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_eo_01.dbf' size 5m
   autoextend on next 5M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_EO_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_eo_ind_01.dbf' size 5m
   autoextend on next 5M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_EVT DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_evt_01.dbf' size 5m
   autoextend on next 5M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_EVT_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_evt_ind_01.dbf' size 5m
   autoextend on next 5M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_IFD DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_ifd_01.dbf' size 10m
   autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_IFD_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_ifd_ind_01.dbf' size 10m
   autoextend on next 10M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

  
CREATE TABLESPACE SL_DEF_OTHER_IND DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_other_ind_01.dbf' size 20m
   autoextend on next 20M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

CREATE TABLESPACE SL_DEF_OTHER DATAFILE
'D:\oracle\oradata\orcl\orcl_sl_def_other_01.dbf' size 20m
   autoextend on next 20M maxsize 2000M
      extent management local uniform size  128k 
      segment space management auto
/

create tablespace EMS_D_01
   datafile
      'D:\oracle\oradata\orcl\orcl_emsd01.dbf' size 50m
   autoextend on next 10M maxsize 20000M
   extent management local uniform size 128K
   segment space management auto
/

create tablespace EMS_X_01
   datafile
      'D:\oracle\oradata\orcl\orcl_emsx01.dbf' size 50m
   autoextend on next 10M maxsize 20000M
   extent management local uniform size 128K
   segment space management auto
/

create tablespace DLX_DATA_TS
   datafile
      'D:\oracle\oradata\orcl\orcl_dlx_data_ts_01.dbf' size 50m
   autoextend on next 10M maxsize 20000M
   extent management local uniform size 128K
   segment space management auto
/

exit
