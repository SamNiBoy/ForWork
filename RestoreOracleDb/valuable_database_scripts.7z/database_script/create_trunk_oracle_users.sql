connect sys/RedPrairie1 as sysdba

REM
REM Create the Export Directory Object
REM

drop directory exportdir
/
create directory exportdir as 'd:\dbbackup'
/

REM 
REM Create the ORACLE Junit user
REM

drop user tmora cascade
/

create user tmora identified by tmora default tablespace DLX_DATA_TS
/

grant alter session,
      create session,
      execute any procedure,
      select_catalog_role,
      select any dictionary,
      create table,
      exp_full_database,
      imp_full_database to tmora
/

grant select on v_$version to tmora
/

grant select on v_$parameter to tmora
/

grant select on sys.obj$ to tmora
/

grant select on v_$lock to tmora
/

grant select on v_$session to tmora
/

grant select on v_$process to tmora
/

grant select on dbms_lock_allocated to tmora
/

grant select on dba_free_space_coalesced to tmora
/

grant select on dba_data_files to tmora
/

REM Grant tablespace access

alter user tmora
quota unlimited on DLX_DATA_TS
quota unlimited on GEN_D_01
quota unlimited on GEN_D_02
quota unlimited on GEN_X_01
quota unlimited on GEN_X_02
quota unlimited on SL_DEF_IFD
quota unlimited on SL_DATA_OTHER
quota unlimited on SL_DEF_OTHER_IND
quota unlimited on SL_DEF_IFD_IND
quota unlimited on SL_DATA_EVT
quota unlimited on SL_DEF_EO_IND
quota unlimited on SL_DATA_EVT_IND
quota unlimited on SL_DATA_IFD_IND
quota unlimited on SL_DEF_OTHER
quota unlimited on SL_DATA_IFD
quota unlimited on SL_DATA_OTHER_IND
quota unlimited on SL_DATA_EO
quota unlimited on SL_DATA_EO_IND
quota unlimited on SL_DEF_EO
quota unlimited on SL_DEF_EVT
quota unlimited on SL_DEF_EVT_IND
quota unlimited on TRACS3_DATA
quota unlimited on TRACS3_HIST
quota unlimited on TRACS3_LOCATIONS
quota unlimited on TRACS3_ORDERS
quota unlimited on TRACS3_TEMP
quota unlimited on TRACS3_HIST_INDEX
quota unlimited on TRACS3_INDEX
quota unlimited on TRACS3_LOCATION_INDEX
quota unlimited on TRACS3_ORDER_INDEX
quota unlimited on PRCL_D_01
quota unlimited on PRCL_X_01
quota unlimited on DDS_D_01
quota unlimited on DDS_D_02
quota unlimited on DDS_X_01
quota unlimited on DDS_X_02
quota unlimited on FP_D_01
quota unlimited on FP_D_02
quota unlimited on FP_D_03
quota unlimited on FP_X_01
quota unlimited on FP_X_02
quota unlimited on FP_X_03
quota unlimited on EMS_D_01
quota unlimited on EMS_X_01
quota unlimited on USERS
/

REM Creating plan_table for the user

connect tmora/tmora

@D:/oracle/product/11.1.0/db_1/rdbms/admin/utlxplan.sql

connect sys/RedPrairie1 as sysdba

grant read, write on directory exportdir to tmora
/

REM
REM Create the Bring Oracle Upgrade user
REM

connect sys/RedPrairie1 as sysdba

drop user bringoraupgtrunk cascade
/

create user bringoraupgtrunk identified by bringoraupgtrunk default tablespace DLX_DATA_TS
/

grant alter session,
      create session,
      execute any procedure,
      select_catalog_role,
      select any dictionary,
      create table,
      exp_full_database,
      imp_full_database to bringoraupgtrunk
/

grant select on v_$version to bringoraupgtrunk
/

grant select on v_$parameter to bringoraupgtrunk
/

grant select on sys.obj$ to bringoraupgtrunk
/

grant select on v_$lock to bringoraupgtrunk
/

grant select on v_$session to bringoraupgtrunk
/

grant select on v_$process to bringoraupgtrunk
/

grant select on dbms_lock_allocated to bringoraupgtrunk
/

grant select on dba_free_space_coalesced to bringoraupgtrunk
/

grant select on dba_data_files to bringoraupgtrunk
/

REM Provide unlimited Quotas on the application tablespaces

alter user bringoraupgtrunk
quota unlimited on DLX_DATA_TS
quota unlimited on GEN_D_01
quota unlimited on GEN_D_02
quota unlimited on GEN_X_01
quota unlimited on GEN_X_02
quota unlimited on SL_DEF_IFD
quota unlimited on SL_DATA_OTHER
quota unlimited on SL_DEF_OTHER_IND
quota unlimited on SL_DEF_IFD_IND
quota unlimited on SL_DATA_EVT
quota unlimited on SL_DEF_EO_IND
quota unlimited on SL_DATA_EVT_IND
quota unlimited on SL_DATA_IFD_IND
quota unlimited on SL_DEF_OTHER
quota unlimited on SL_DATA_IFD
quota unlimited on SL_DATA_OTHER_IND
quota unlimited on SL_DATA_EO
quota unlimited on SL_DATA_EO_IND
quota unlimited on SL_DEF_EO
quota unlimited on SL_DEF_EVT
quota unlimited on SL_DEF_EVT_IND
quota unlimited on TRACS3_DATA
quota unlimited on TRACS3_HIST
quota unlimited on TRACS3_LOCATIONS
quota unlimited on TRACS3_ORDERS
quota unlimited on TRACS3_TEMP
quota unlimited on TRACS3_HIST_INDEX
quota unlimited on TRACS3_INDEX
quota unlimited on TRACS3_LOCATION_INDEX
quota unlimited on TRACS3_ORDER_INDEX
quota unlimited on PRCL_D_01
quota unlimited on PRCL_X_01
quota unlimited on DDS_D_01
quota unlimited on DDS_D_02
quota unlimited on DDS_X_01
quota unlimited on DDS_X_02
quota unlimited on FP_D_01
quota unlimited on FP_D_02
quota unlimited on FP_D_03
quota unlimited on FP_X_01
quota unlimited on FP_X_02
quota unlimited on FP_X_03
quota unlimited on EMS_D_01
quota unlimited on EMS_X_01
quota unlimited on USERS
/

REM Creating plan_table for the user

connect bringoraupgtrunk/bringoraupgtrunk

@D:/oracle/product/11.1.0/db_1/rdbms/admin/utlxplan.sql

connect sys/RedPrairie1 as sysdba

grant read, write on directory exportdir to bringoraupgtrunk
/

REM
REM Create the Oracle Fitnesse user
REM

connect sys/RedPrairie1 as sysdba

drop user tmorafit cascade
/

create user tmorafit identified by tmorafit default tablespace DLX_DATA_TS
/

grant alter session,
      create session,
      execute any procedure,
      select_catalog_role,
      select any dictionary,
      create table,
      exp_full_database,
      imp_full_database to tmorafit
/

grant select on v_$version to tmorafit
/

grant select on v_$parameter to tmorafit
/

grant select on sys.obj$ to tmorafit
/

grant select on v_$lock to tmorafit
/

grant select on v_$session to tmorafit
/

grant select on v_$process to tmorafit
/

grant select on dbms_lock_allocated to tmorafit
/

grant select on dba_free_space_coalesced to tmorafit
/

grant select on dba_data_files to tmorafit
/

REM Provide unlimited Quotas on the application tablespaces

alter user tmorafit
quota unlimited on DLX_DATA_TS
quota unlimited on GEN_D_01
quota unlimited on GEN_D_02
quota unlimited on GEN_X_01
quota unlimited on GEN_X_02
quota unlimited on SL_DEF_IFD
quota unlimited on SL_DATA_OTHER
quota unlimited on SL_DEF_OTHER_IND
quota unlimited on SL_DEF_IFD_IND
quota unlimited on SL_DATA_EVT
quota unlimited on SL_DEF_EO_IND
quota unlimited on SL_DATA_EVT_IND
quota unlimited on SL_DATA_IFD_IND
quota unlimited on SL_DEF_OTHER
quota unlimited on SL_DATA_IFD
quota unlimited on SL_DATA_OTHER_IND
quota unlimited on SL_DATA_EO
quota unlimited on SL_DATA_EO_IND
quota unlimited on SL_DEF_EO
quota unlimited on SL_DEF_EVT
quota unlimited on SL_DEF_EVT_IND
quota unlimited on TRACS3_DATA
quota unlimited on TRACS3_HIST
quota unlimited on TRACS3_LOCATIONS
quota unlimited on TRACS3_ORDERS
quota unlimited on TRACS3_TEMP
quota unlimited on TRACS3_HIST_INDEX
quota unlimited on TRACS3_INDEX
quota unlimited on TRACS3_LOCATION_INDEX
quota unlimited on TRACS3_ORDER_INDEX
quota unlimited on PRCL_D_01
quota unlimited on PRCL_X_01
quota unlimited on DDS_D_01
quota unlimited on DDS_D_02
quota unlimited on DDS_X_01
quota unlimited on DDS_X_02
quota unlimited on FP_D_01
quota unlimited on FP_D_02
quota unlimited on FP_D_03
quota unlimited on FP_X_01
quota unlimited on FP_X_02
quota unlimited on FP_X_03
quota unlimited on EMS_D_01
quota unlimited on EMS_X_01
quota unlimited on USERS
/

REM Creating plan_table for the user

connect tmorafit/tmorafit

@D:/oracle/product/11.1.0/db_1/rdbms/admin/utlxplan.sql

connect sys/RedPrairie1 as sysdba

grant read, write on directory exportdir to tmorafit
/

REM
REM Create the ORACLE Upgrade User
REM

connect sys/RedPrairie1 as sysdba

drop user tmoraupg cascade
/

create user tmoraupg identified by tmoraupg default tablespace DLX_DATA_TS
/

grant alter session,
      create session,
      execute any procedure,
      select_catalog_role,
      select any dictionary,
      create table,
      exp_full_database,
      imp_full_database to tmoraupg
/

grant select on v_$version to tmoraupg
/

grant select on v_$parameter to tmoraupg
/

grant select on sys.obj$ to tmoraupg
/

grant select on v_$lock to tmoraupg
/

grant select on v_$session to tmoraupg
/

grant select on v_$process to tmoraupg
/

grant select on dbms_lock_allocated to tmoraupg
/

grant select on dba_free_space_coalesced to tmoraupg
/

grant select on dba_data_files to tmoraupg
/

REM Provide unlimited Quotas on the application tablespaces

alter user tmoraupg
quota unlimited on DLX_DATA_TS
quota unlimited on GEN_D_01
quota unlimited on GEN_D_02
quota unlimited on GEN_X_01
quota unlimited on GEN_X_02
quota unlimited on SL_DEF_IFD
quota unlimited on SL_DATA_OTHER
quota unlimited on SL_DEF_OTHER_IND
quota unlimited on SL_DEF_IFD_IND
quota unlimited on SL_DATA_EVT
quota unlimited on SL_DEF_EO_IND
quota unlimited on SL_DATA_EVT_IND
quota unlimited on SL_DATA_IFD_IND
quota unlimited on SL_DEF_OTHER
quota unlimited on SL_DATA_IFD
quota unlimited on SL_DATA_OTHER_IND
quota unlimited on SL_DATA_EO
quota unlimited on SL_DATA_EO_IND
quota unlimited on SL_DEF_EO
quota unlimited on SL_DEF_EVT
quota unlimited on SL_DEF_EVT_IND
quota unlimited on TRACS3_DATA
quota unlimited on TRACS3_HIST
quota unlimited on TRACS3_LOCATIONS
quota unlimited on TRACS3_ORDERS
quota unlimited on TRACS3_TEMP
quota unlimited on TRACS3_HIST_INDEX
quota unlimited on TRACS3_INDEX
quota unlimited on TRACS3_LOCATION_INDEX
quota unlimited on TRACS3_ORDER_INDEX
quota unlimited on PRCL_D_01
quota unlimited on PRCL_X_01
quota unlimited on DDS_D_01
quota unlimited on DDS_D_02
quota unlimited on DDS_X_01
quota unlimited on DDS_X_02
quota unlimited on FP_D_01
quota unlimited on FP_D_02
quota unlimited on FP_D_03
quota unlimited on FP_X_01
quota unlimited on FP_X_02
quota unlimited on FP_X_03
quota unlimited on EMS_D_01
quota unlimited on EMS_X_01
quota unlimited on USERS
/

REM Creating plan_table for the user

connect tmoraupg/tmoraupg

@D:/oracle/product/11.1.0/db_1/rdbms/admin/utlxplan.sql


connect sys/RedPrairie1 as sysdba

grant read, write on directory exportdir to tmoraupg
/

exit
