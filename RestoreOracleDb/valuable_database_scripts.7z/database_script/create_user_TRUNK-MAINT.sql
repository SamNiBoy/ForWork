connect sys/RedPrairie1 as sysdba

drop user trunkmaint cascade
/

create user trunkmaint identified by trunkmaint default tablespace DLX_DATA_TS
/

grant alter session,
      create session,
      execute any procedure,
      select_catalog_role,
      select any dictionary,
      create table,
      exp_full_database,
      imp_full_database to trunkmaint
/

grant select on v_$version to trunkmaint
/

grant select on v_$parameter to trunkmaint
/

grant select on sys.obj$ to trunkmaint
/

grant select on v_$lock to trunkmaint
/

grant select on v_$session to trunkmaint
/

grant select on v_$process to trunkmaint
/

grant select on dbms_lock_allocated to trunkmaint
/

grant select on dba_free_space_coalesced to trunkmaint
/

grant select on dba_data_files to trunkmaint
/


REM Provide unlimited Quotas on the application tablespaces
REM

alter user trunkmaint
quota unlimited on DLX_DATA_TS
quota unlimited on GEN_D_01
quota unlimited on GEN_D_02
quota unlimited on GEN_X_01
quota unlimited on GEN_X_02
quota unlimited on SL_DEF_IFD
quota unlimited on SL_DATA_OTHER
quota unlimited on SL_DEF_OTHER_IND
quota unlimited on SL_DEF_IFD_IND
quota unlimited on SL_DATA_EVT
quota unlimited on SL_DEF_EO_IND
quota unlimited on SL_DATA_EVT_IND
quota unlimited on SL_DATA_IFD_IND
quota unlimited on SL_DEF_OTHER
quota unlimited on SL_DATA_IFD
quota unlimited on SL_DATA_OTHER_IND
quota unlimited on SL_DATA_EO
quota unlimited on SL_DATA_EO_IND
quota unlimited on SL_DEF_EO
quota unlimited on SL_DEF_EVT
quota unlimited on SL_DEF_EVT_IND
quota unlimited on TRACS3_DATA
quota unlimited on TRACS3_HIST
quota unlimited on TRACS3_LOCATIONS
quota unlimited on TRACS3_ORDERS
quota unlimited on TRACS3_TEMP
quota unlimited on TRACS3_HIST_INDEX
quota unlimited on TRACS3_INDEX
quota unlimited on TRACS3_LOCATION_INDEX
quota unlimited on TRACS3_ORDER_INDEX
quota unlimited on PRCL_D_01
quota unlimited on PRCL_X_01
quota unlimited on DDS_D_01
quota unlimited on DDS_D_02
quota unlimited on DDS_X_01
quota unlimited on DDS_X_02
quota unlimited on FP_D_01
quota unlimited on FP_D_02
quota unlimited on FP_D_03
quota unlimited on FP_X_01
quota unlimited on FP_X_02
quota unlimited on FP_X_03
/

REM Creating plan_table for the user

connect trunkmaint/trunkmaint

@D:/oracle/product/11.1.0/db_1/rdbms/admin/utlxplan.sql


connect / as sysdba

exit
