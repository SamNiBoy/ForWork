drop user &1 cascade
/

exit