purge recyclebin
/

exit
/