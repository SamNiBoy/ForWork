USE MASTER
GO

PRINT('')
PRINT('-----------------------------------------------------------')
PRINT('Killing any outstanding processes before RESTORE...')
PRINT('-----------------------------------------------------------')
PRINT('')

DECLARE @DatabaseName SYSNAME
DECLARE @BackupFile VARCHAR(2000)
DECLARE @NumberOfTimesToLoop INT
-- Time to wait between checks
-- should be between 1 to 599 seconds.
DECLARE @TimeToCheckKillInSec INT

SET @DatabaseName = '$(database)'
SET @BackupFile = '$(backupfile)'
SET @NumberOfTimesToLoop = 2
SET @TimeToCheckKillInSec = 3


DECLARE @WaitTimeStr VARCHAR(8)
DECLARE @i INT
DECLARE @sCurrentSPIDToKill VARCHAR(32)
DECLARE @sSPID VARCHAR(32)
DECLARE @ServerVersion NVARCHAR(128)

SET @sSPID = CAST(@@SPID AS VARCHAR(32))

IF OBJECT_ID('tempdb..#utbSPWHO2', 'TABLE') IS NOT NULL
        DROP TABLE #utbSPWHO2

CREATE TABLE #utbSPWHO2 (
        SPID INT,
        [Status] NVARCHAR(128),
        LoginName NVARCHAR(128),
        HostName NVARCHAR(128),
        BlockedBy NVARCHAR(32),
        DBName NVARCHAR(128),
        Command NVARCHAR(128),
        CPUTime NVARCHAR(64),
        DiskIO NVARCHAR(64),
        LastBatchRunTime NVARCHAR(64),
        ProgramName NVARCHAR(512),
        SPID2 INT,
        RequestID INT)

-- The clustered index uses the current @@SPID to make
-- sure that the index name is unique.
EXEC('CREATE CLUSTERED INDEX
CI_#utbSPWHO2_' + @sSPID + '
ON #utbSPWHO2 (LoginName, DBName, SPID)')

-- sp_who2 is version-sensitive - RequestID is returned
-- for SQL 2K5 and later but not in SQL 2K.
SET @ServerVersion = CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128))

-- Get the sp_who2 results.
IF @ServerVersion LIKE '8.%' OR @ServerVersion LIKE '7.%'
        INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2)
        EXEC sp_who2        
ELSE
        INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2, RequestID)
        EXEC sp_who2


IF NOT EXISTS(
        SELECT *
        FROM #utbSPWHO2
        WHERE DBName = @DatabaseName)
BEGIN
        PRINT('No processes where killed.')
END

-- @WaitTimeStr is used in a WAITFOR DELAY command later.
SET @WaitTimeStr = '00:0' + CAST(@TimeToCheckKillInSec/60 AS CHAR(1))
        + CASE WHEN (@TimeToCheckKillInSec%60) < 10
               THEN ':0'
               ELSE ':'
          END
        + CAST(@TimeToCheckKillInSec%60 AS VARCHAR(2))

-- Get the first SPID to kill. HostName is checked as well
-- to make sure we don't kill internal machine processes.
SELECT @sCurrentSPIDToKill = CAST(MIN(SPID) AS VARCHAR(32))
FROM #utbSPWHO2
WHERE DBName = @DatabaseName
        AND RTRIM(LTRIM(HostName)) <> N'.'
        AND SPID <> @@SPID

WHILE @sCurrentSPIDToKill IS NOT NULL
BEGIN
        -- Launch the KILL command.
        EXEC('KILL ' + @sCurrentSPIDToKill)
        
        -- Check if the process was killed
        TRUNCATE TABLE #utbSPWHO2
        
        IF @ServerVersion LIKE '8.%' OR @ServerVersion LIKE '7.%'
                INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2)
                EXEC sp_who2        
        ELSE
                INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2, RequestID)
                EXEC sp_who2

        
        SET @i = 1

        WHILE EXISTS(
        SELECT *
        FROM #utbSPWHO2
        WHERE DBName = @DatabaseName
                AND SPID = CAST(@sCurrentSPIDToKill AS INT))

        AND @i <= @NumberOfTimesToLoop

        BEGIN
                -- Wait and check if the process was killed again.
                WAITFOR DELAY @WaitTimeStr
                
                -- Check if the process was killed
                TRUNCATE TABLE #utbSPWHO2
                
                IF @ServerVersion LIKE '8.%' OR @ServerVersion LIKE '7.%'
                        INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2)
                        EXEC sp_who2        
                ELSE
                        INSERT INTO #utbSPWHO2 (SPID, [Status], LoginName, HostName, BlockedBy, DBName, Command, CPUTime, DiskIO, LastBatchRunTime, ProgramName, SPID2, RequestID)
                        EXEC sp_who2
                

                SET @i = @i + 1
        END

        -- Check if loop exited because process was killed
        -- or due to too many loop.
        IF @i > @NumberOfTimesToLoop
        BEGIN
                -- Too many loop. Abort and notify the user.
                RAISERROR('The script could not kill process id = %s.', 16, 1, @sCurrentSPIDToKill)
                RETURN
        END
        ELSE
                PRINT('Process id ' + @sCurrentSPIDToKill + ' was killed successfully')

        -- If we got this far then the process was killed
        -- and we need to find the next process to kill.
        SET @sCurrentSPIDToKill = NULL

        SELECT @sCurrentSPIDToKill = CAST(MIN(SPID) AS VARCHAR(32))
        FROM #utbSPWHO2
        WHERE DBName = @DatabaseName
                AND RTRIM(LTRIM(HostName)) <> N'.'
                AND SPID <> @@SPID
END

GO

DECLARE @DatabaseName SYSNAME
DECLARE @BackupFile VARCHAR(2000)

SET @DatabaseName = '$(database)'
SET @BackupFile = '$(backupfile)'

IF NOT EXISTS (SELECT * 
             FROM sys.databases 
            WHERE name = @DatabaseName)
BEGIN
    PRINT('DATABASE ' + @DatabaseName + 'DOES NOT EXIST.')
END    
ELSE
BEGIN

    PRINT('')
    PRINT('------------------------------------------------------------------')
    PRINT('Putting database ' + @DatabaseName + ' into single user mode')
    PRINT('------------------------------------------------------------------')

    EXEC('ALTER DATABASE [' + @DatabaseName + '] SET SINGLE_USER WITH ROLLBACK IMMEDIATE')

    PRINT('')
    PRINT('------------------------------------------------------------------')
    PRINT('Starting Database Restore of ' + @BackupFile + ' into ' + @DatabaseName)
    PRINT('------------------------------------------------------------------')

    PRINT('')
    PRINT('>> Dropping possible GUI snapshot of ' + @DatabaseName + '...')

    --
    -- Get the database snapshot
    --

    DECLARE @snapshotName SYSNAME

    IF EXISTS (SELECT *
                 FROM sys.databases snpsht, 
                      sys.databases origdb
                WHERE origdb.name = @DatabaseName
                  AND origdb.database_id = snpsht.source_database_id
                  AND snpsht.is_read_only = 1)
    BEGIN

        SELECT @snapshotName = snpsht.name 
          FROM sys.databases snpsht, 
               sys.databases origdb
         WHERE origdb.name = @DatabaseName
            AND origdb.database_id = snpsht.source_database_id
            AND snpsht.is_read_only = 1
   
        EXEC('DROP DATABASE [' + @snapshotName + ']')
      
    END
    ELSE
    BEGIN
        PRINT('    No snapshots found.')
    END

    PRINT('')
    PRINT('>> Retrieving logical names and physical file locations for ' + @DatabaseName + '...')

    --
    -- Get the database key that the database is known by
    --

    DECLARE @databaseId INT
    DECLARE @toDataName VARCHAR(100)
    DECLARE @toDataFileName VARCHAR(2000)
    DECLARE @toLogName VARCHAR(100)
    DECLARE @toLogFileName VARCHAR(2000)

    SET @toDataName = @DatabaseName
    SET @toLogName = @DatabaseName + "_log"

    --
    -- Get the current physical file names for the restore-to database
    --

    SELECT @databaseId = database_id 
      FROM master.sys.databases 
     WHERE name = @DatabaseName

    SELECT @toDataFileName = msmf.physical_name
      FROM master.sys.master_files msmf,
           master.sys.databases msd
     WHERE msmf.database_id = msd.database_id
       AND msmf.type_desc = 'ROWS'
       AND msd.name = @DatabaseName

    SELECT @toLogFileName = msmf.physical_name
      FROM master.sys.master_files msmf,
           master.sys.databases msd
     WHERE msmf.database_id = msd.database_id
       AND msmf.type_desc = 'LOG'
       AND msd.name = @DatabaseName

    PRINT('---- Data Name: (' + @toDataName + ')')
    PRINT('---- Data File: (' + @toDataFileName + ')')
    PRINT('---- Log Name: (' + @toLogName + ')')
    PRINT('---- Log File: (' + @toLogFileName + ')')

    -- 
    -- Get the logical file names of the database within the backup file
    --

    PRINT('')
    PRINT('>> Retrieving logical names within ' + @BackupFile + '...')

    IF EXISTS (SELECT * 
                 FROM sys.objects 
                WHERE object_id = OBJECT_ID(N'[dbo].[backupFileList]')
                  AND type in (N'U'))
    BEGIN
        DROP TABLE [backupFileList]
    END

    -- WARNING!  THIS TABLE STRUCTURE IS FOR SQL SERVER 2008 R2
    CREATE TABLE backupFileList
    (
        LogicalName  nvarchar(128),
        PhysicalName nvarchar(2000),
        [Type]   char(1),
        FileGroupName nvarchar(128) null,
        Size   numeric(20, 0),
        MaxSize   numeric(20, 0),
        FileId   int null,
        CreateLSN    numeric(25,0) null,
        DropLSN     numeric(25,0) null,
        UniqueId  uniqueidentifier null,
        readonlyLSN     numeric(25,0) null,
        readwriteLSN     numeric(25,0) null,
        BackupSizeInBytes bigint null,
        SourceBlockSize  int null,
        FileGroupId  int null,
        LogGroupGuid  uniqueidentifier null,
        DifferentialBaseLsn numeric(25,0) null,
        DifferentialBaseGuid uniqueidentifier null,
        IsReadOnly  bit null,
        IsPresent  bit null,
        TDEThumbprint varchar(200) null
    )

    INSERT backupFileList
      EXEC ('RESTORE FILELISTONLY FROM DISK=''' + @BackupFile + '''')

    DECLARE @fromDataName VARCHAR(200)
    DECLARE @fromLogName VARCHAR(200)

    SELECT @fromDataName = LogicalName
      FROM backupFileList
     WHERE [TYPE] = 'D'
 
    SELECT @fromLogName = LogicalName
      FROM backupFileList
     WHERE [TYPE] = 'L'

    DROP TABLE backupFileList

    PRINT('---- Logical Data Name: (' + @fromDataName + ')')
    PRINT('---- Logical Log Name: (' + @fromLogName + ')')

    --
    -- Restore the backup file
    --

    PRINT('')
    PRINT('>> Restoring backup file ' + @BackupFile)

    EXEC('RESTORE DATABASE [' + @DatabaseName + ']
 FROM DISK = ''' + @BackupFile + '''
 WITH FILE = 1,
 MOVE ''' + @fromDataName + ''' TO ''' + @toDataFileName + ''', 
 MOVE ''' + @fromLogName + ''' TO ''' + @toLogFileName + ''',
 NOUNLOAD, REPLACE, STATS = 10')

    --
    -- Correct the logical names of the restored database
    --

    PRINT('')
    PRINT('>> Correcting logical file names for ' + @DatabaseName + '...')

    IF (@fromDataName = @toDataName)
    
        PRINT('---- Logical Data Name already correct.')

    ELSE

        EXEC('ALTER DATABASE [' + @DatabaseName + ']
 MODIFY FILE (NAME = [' + @fromDataName + '], NEWNAME = [' + @toDataName + '])')

    if (@fromLogName = @toLogName)

        PRINT('---- Logical Log Name already correct.')

    ELSE   

        EXEC('ALTER DATABASE [' + @DatabaseName + ']
 MODIFY FILE (NAME = [' + @fromLogName + '], NEWNAME = [' + @toLogName + '])')

    --
    -- Re-add the db user to the database just restored if it doesn't exist
    --

    PRINT('')
    PRINT('>> Adding User ' + @DatabaseName + ' to database ' + @DatabaseName)
    EXEC('USE [' + @DatabaseName + ']; 
 IF EXISTS (SELECT * 
              FROM SYS.DATABASE_PRINCIPALS 
             WHERE NAME = ''' + @DatabaseName + ''')
     DROP USER [' + @DatabaseName +']
 CREATE USER [' + @DatabaseName + '] FOR LOGIN [' + @DatabaseName + ']
 EXEC sp_addrolemember ''db_owner'', ''' + @DatabaseName + '''')

    --
    --  Set the isolation level of the restored database
    --

    PRINT('')
    PRINT('>> Setting READ_COMMITTED_SNAPSHOT for database ' + @DatabaseName)
    EXEC('ALTER DATABASE [' + @DatabaseName + '] SET READ_COMMITTED_SNAPSHOT on')

END

PRINT('')
PRINT('-----------------------------------------------------------')
PRINT('RESTORE complete.')
PRINT('-----------------------------------------------------------')
PRINT('')

